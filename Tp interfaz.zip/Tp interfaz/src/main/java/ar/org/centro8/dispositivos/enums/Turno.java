package ar.org.centro8.dispositivos.enums;

public enum Turno {
    MAÑANA,TARDE,NOCHE
}